
// Chess.js and Chessboard.js initialization
const game = new Chess();
const board = Chessboard('board', {
    position: 'start',
    draggable: true,
    onDrop: handleMove
});

// Define the moves for the selected opening (Ruy López as an example)
const openingMoves = ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5']; // Correct sequence
let currentMoveIndex = 0;

// Display message to the user
const messageEl = document.getElementById('message');

// Handle player moves
function handleMove(source, target, piece) {
    const move = `${source}${target}`; // Example: e2e4
    const moveObject = game.move({ from: source, to: target });

    if (!moveObject) {
        messageEl.textContent = "Invalid move! Try again.";
        return 'snapback';
    }

    // Check if move matches the opening sequence
    const expectedMove = openingMoves[currentMoveIndex];
    const moveNotation = moveObject.san; // Standard Algebraic Notation (e.g., e4, Nf3)
    if (moveNotation === expectedMove) {
        currentMoveIndex++;
        messageEl.textContent = `Good move! Next: ${openingMoves[currentMoveIndex] || 'All moves completed!'}`;
    } else {
        messageEl.textContent = `Incorrect move. Expected: ${expectedMove}. Restart to try again.`;
        board.position(game.fen());
        return 'snapback';
    }

    // If the player completes the opening sequence
    if (currentMoveIndex === openingMoves.length) {
        messageEl.textContent = "Well done! You completed the opening!";
    }
}

// Restart button functionality
document.getElementById('resetBtn').addEventListener('click', () => {
    game.reset();
    board.position('start');
    currentMoveIndex = 0;
    messageEl.textContent = "Make your move!";
});
